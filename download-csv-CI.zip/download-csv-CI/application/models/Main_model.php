<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Main_model extends CI_Model {

    function getUserDetails(){
        
        $response = array();
           
        // Select record
        $this->db->select('first_name,last_name,email,age,status');
        $q = $this->db->get('employee');
        $response = $q->result_array();
        
        return $response;
    }

}