<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Export MySQL data to CSV file in CodeIgniter</title>

	
</head>
<body>

	<!-- Export Data -->
	<a href='<?= base_url() ?>index.php/users/exportCSV'>Export</a><br><br>

	<!-- User Records -->
	<table border='1' style='border-collapse: collapse;'>
		<thead>
			<tr>
				<th>Fname</th>
				<th>Lname</th>
				<th>Email</th>
				<th>Age</th>
				<th>Status</th>
			</tr>
		</thead>
		<tbody>
			<?php

			foreach($usersData as $key=>$val){
				echo "<tr>";
				echo "<td>".$val['first_name']."</td>";
				echo "<td>".$val['last_name']."</td>";
				echo "<td>".$val['email']."</td>";
				echo "<td>".$val['age']."</td>";
				echo "<td>".$val['status']."</td>";
				echo "</tr>";
			}
			?>
		</tbody>
	</table>

</body>
</html>